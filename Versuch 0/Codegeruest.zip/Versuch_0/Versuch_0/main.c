#include <avr/io.h>


int main(void){
	
	
    /* Replace with your application code */
    while (1) 
    {
    }
}

