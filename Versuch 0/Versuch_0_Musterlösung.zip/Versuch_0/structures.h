/*
 * structures.h
 *
 * Created: 31.03.2014 16:53:02
 *  Author: Stefan
 */ 


#ifndef STRUCTURES_H_
#define STRUCTURES_H_

void displayArticles();



#endif /* STRUCTURES_H_ */