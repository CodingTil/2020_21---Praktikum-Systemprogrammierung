/*
 * datatyes.h
 *
 * Created: 31.01.2014 10:05:59
 *  Author: sr466916
 */ 


#ifndef DATATYES_H_
#define DATATYES_H_

#include "lcd.h"

void convert();

void loop();

void shift();


#endif /* DATATYES_H_ */