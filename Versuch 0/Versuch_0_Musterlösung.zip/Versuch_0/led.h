/*
 * led.h
 *
 * Created: 31.01.2014 10:15:03
 *  Author: sr466916
 */ 


#ifndef LED_H_
#define LED_H_

void led_init();

void led_fun();


#endif /* LED_H_ */