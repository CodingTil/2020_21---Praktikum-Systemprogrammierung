var searchData=
[
  ['gethighnibble_349',['getHighNibble',['../os__memory_8c.html#ae420976ba4abbd069aff795935b9636c',1,'os_memory.c']]],
  ['getlownibble_350',['getLowNibble',['../os__memory_8c.html#a01bd9b56dbbeb0af404043ceca5c8818',1,'os_memory.c']]],
  ['getownerofchunk_351',['getOwnerOfChunk',['../os__memory_8c.html#ab493cf6ec58f933b4751b0d2a2f77c4a',1,'os_memory.c']]],
  ['getsystemtime_352',['getSystemTime',['../util_8c.html#a31a009dd17764a744deeda855ba66954',1,'getSystemTime(void):&#160;util.c'],['../util_8h.html#a31a009dd17764a744deeda855ba66954',1,'getSystemTime(void):&#160;util.c']]]
];
