var searchData=
[
  ['pagehandlerwrapper_460',['pageHandlerWrapper',['../os__taskman_8c.html#abe083099a41966d5056f80c242f7832e',1,'os_taskman.c']]],
  ['pqueue_5fappend_461',['pqueue_append',['../os__scheduling__strategies_8c.html#a3ae034c3452457a90dd7c074ca5c3aaf',1,'pqueue_append(ProcessQueue *queue, ProcessID pid):&#160;os_scheduling_strategies.c'],['../os__scheduling__strategies_8h.html#a3ae034c3452457a90dd7c074ca5c3aaf',1,'pqueue_append(ProcessQueue *queue, ProcessID pid):&#160;os_scheduling_strategies.c']]],
  ['pqueue_5fdropfirst_462',['pqueue_dropFirst',['../os__scheduling__strategies_8c.html#af2fe5737d2380feb249f6798c75279e0',1,'pqueue_dropFirst(ProcessQueue *queue):&#160;os_scheduling_strategies.c'],['../os__scheduling__strategies_8h.html#af2fe5737d2380feb249f6798c75279e0',1,'pqueue_dropFirst(ProcessQueue *queue):&#160;os_scheduling_strategies.c']]],
  ['pqueue_5fgetfirst_463',['pqueue_getFirst',['../os__scheduling__strategies_8c.html#ad6b26362a90e689ff188d2492a616eef',1,'pqueue_getFirst(ProcessQueue *queue):&#160;os_scheduling_strategies.c'],['../os__scheduling__strategies_8h.html#ad6b26362a90e689ff188d2492a616eef',1,'pqueue_getFirst(ProcessQueue *queue):&#160;os_scheduling_strategies.c']]],
  ['pqueue_5fhasnext_464',['pqueue_hasNext',['../os__scheduling__strategies_8c.html#a7e2b52989067e26dde40df65a79ab934',1,'pqueue_hasNext(ProcessQueue *queue):&#160;os_scheduling_strategies.c'],['../os__scheduling__strategies_8h.html#a7e2b52989067e26dde40df65a79ab934',1,'pqueue_hasNext(ProcessQueue *queue):&#160;os_scheduling_strategies.c']]],
  ['pqueue_5finit_465',['pqueue_init',['../os__scheduling__strategies_8c.html#abcf6f70d0ed60b64437107c94ff0b9f7',1,'pqueue_init(ProcessQueue *queue):&#160;os_scheduling_strategies.c'],['../os__scheduling__strategies_8h.html#abcf6f70d0ed60b64437107c94ff0b9f7',1,'pqueue_init(ProcessQueue *queue):&#160;os_scheduling_strategies.c']]],
  ['pqueue_5fremovepid_466',['pqueue_removePID',['../os__scheduling__strategies_8c.html#affb2ae62bc6e6ae2502d9dba66c1e5a7',1,'os_scheduling_strategies.c']]],
  ['pqueue_5freset_467',['pqueue_reset',['../os__scheduling__strategies_8c.html#aa6830b1c1886efadb22b77bcc0775a7c',1,'pqueue_reset(ProcessQueue *queue):&#160;os_scheduling_strategies.c'],['../os__scheduling__strategies_8h.html#aa6830b1c1886efadb22b77bcc0775a7c',1,'pqueue_reset(ProcessQueue *queue):&#160;os_scheduling_strategies.c']]],
  ['priorityconsttext_468',['priorityConstText',['../os__taskman_8c.html#a7f8306eccb29dffa80915593fc9476e5',1,'os_taskman.c']]],
  ['procmutator_469',['procMutator',['../os__taskman_8c.html#abe6170c3799d91c140f779ae3f8a5bd9',1,'os_taskman.c']]],
  ['procmutatorconfirm_470',['procMutatorConfirm',['../os__taskman_8c.html#aa954f74a0cab90c57923de152aa3f4d8',1,'os_taskman.c']]],
  ['program_471',['PROGRAM',['../os__scheduler_8c.html#abd0d27876e5dadc4f719a0fb8fd279d8',1,'os_scheduler.c']]]
];
