var searchData=
[
  ['savecontext_618',['saveContext',['../util_8h.html#a95d67df1cf6117ce43766d06b8113297',1,'util.h']]],
  ['ss_5fmax_5fcount_619',['SS_MAX_COUNT',['../os__taskman_8c.html#a2b3e861d6a765c038765f25287412c6a',1,'os_taskman.c']]],
  ['stack_5fsize_5fisr_620',['STACK_SIZE_ISR',['../defines_8h.html#a5897211c66fb513c0e45424e77446325',1,'defines.h']]],
  ['stack_5fsize_5fmain_621',['STACK_SIZE_MAIN',['../defines_8h.html#a0187f5405175817f5d15b70f2d5ba908',1,'defines.h']]],
  ['stack_5fsize_5fproc_622',['STACK_SIZE_PROC',['../defines_8h.html#a69935146762e044c13bc1e04e159ac7f',1,'defines.h']]]
];
