var searchData=
[
  ['mainlabels_499',['mainLabels',['../os__taskman_8c.html#a2f8147c4416ce08ba8f3290d82af05a5',1,'os_taskman.c']]]
];
