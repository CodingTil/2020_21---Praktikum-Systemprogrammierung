var searchData=
[
  ['_5f_5fheap_5fstart_486',['__heap_start',['../os__core_8h.html#aa1b242a8ba3e152cede356fe4e176ff6',1,'os_core.h']]]
];
