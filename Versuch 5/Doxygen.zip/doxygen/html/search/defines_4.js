var searchData=
[
  ['es_573',['ES',['../os__taskman_8c.html#a403811204922acc8d200abb94fa62fe4',1,'os_taskman.c']]],
  ['extheap_574',['extHeap',['../os__memheap__drivers_8h.html#a9d3e12d77e5d6a64c38d9d52a4aef469',1,'os_memheap_drivers.h']]],
  ['extsram_575',['extSRAM',['../os__mem__drivers_8h.html#aab38e0df15a7e7bbdc0de32e168b1daa',1,'os_mem_drivers.h']]]
];
