var searchData=
[
  ['call_410',['call',['../struct_page_state.html#a628185dec95e935fc0f29a97e2d33421',1,'PageState']]],
  ['child_411',['child',['../struct_page_result.html#aef6d9b33a716552010f677eb0ccad559',1,'PageResult']]],
  ['criticalsectioncount_412',['criticalSectionCount',['../os__scheduler_8c.html#a3e46b6c5f8524eb09423304c15f9ed02',1,'os_scheduler.c']]],
  ['currentproc_413',['currentProc',['../os__scheduler_8c.html#adb0cb32ce54e018ec562646256effc70',1,'currentProc():&#160;os_scheduler.c'],['../os__taskman_8c.html#adb0cb32ce54e018ec562646256effc70',1,'currentProc():&#160;os_scheduler.c']]],
  ['currschedstrat_414',['currSchedStrat',['../os__scheduler_8c.html#ad27041c2a3c9f0fe802bc0c6e485080c',1,'os_scheduler.c']]]
];
