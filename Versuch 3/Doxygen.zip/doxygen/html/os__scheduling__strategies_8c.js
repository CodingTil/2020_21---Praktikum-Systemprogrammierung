var os__scheduling__strategies_8c =
[
    [ "isAnyProcReady", "os__scheduling__strategies_8c.html#a0bb20f041ecb373f5b3c6a36ba1e5ecf", null ],
    [ "os_resetProcessSchedulingInformation", "os__scheduling__strategies_8c.html#aefdd44d05e14f2de4e9853aa83faf98c", null ],
    [ "os_resetSchedulingInformation", "os__scheduling__strategies_8c.html#af63ac803dcc59d7fe7f363c1cf6d5b66", null ],
    [ "os_Scheduler_Even", "os__scheduling__strategies_8c.html#a9266a96f24baa8d3855336fb9e04f3e3", null ],
    [ "os_Scheduler_InactiveAging", "os__scheduling__strategies_8c.html#a971f4f9398aabe24922871fbaddc2a79", null ],
    [ "os_Scheduler_Random", "os__scheduling__strategies_8c.html#a76e97c5980ec62d7cfcd20afabf5a13a", null ],
    [ "os_Scheduler_RoundRobin", "os__scheduling__strategies_8c.html#ae37e8a914b50dfc9eb419a63e346b3d1", null ],
    [ "os_Scheduler_RunToCompletion", "os__scheduling__strategies_8c.html#a74d94ddb0f07c51e7af05c9b0f76c135", null ],
    [ "schedulingInfo", "os__scheduling__strategies_8c.html#aadb0e3d669bbca5d4d424f4ba8724848", null ]
];