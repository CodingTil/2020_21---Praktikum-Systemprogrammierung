var os__taskman_8h =
[
    [ "os_taskManMain", "os__taskman_8h.html#aa943b0ea6ad57c5564aa0534778ad7f3", null ],
    [ "os_taskManOpen", "os__taskman_8h.html#af69cf320b7a9fd3fbfb57ba7c3f996de", null ]
];