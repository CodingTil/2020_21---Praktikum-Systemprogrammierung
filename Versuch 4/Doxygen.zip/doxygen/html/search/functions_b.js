var searchData=
[
  ['updateinputp_437',['updateInputP',['../os__taskman_8c.html#a51fe3b40f37941eaca4c0bf3719736e7',1,'os_taskman.c']]]
];
