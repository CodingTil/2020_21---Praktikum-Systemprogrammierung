var searchData=
[
  ['os_5fautostart_454',['os_autostart',['../os__scheduler_8c.html#a9170cd53c1eb116d8ecb55539289c53f',1,'os_scheduler.c']]],
  ['os_5fcoarsesystemtime_455',['os_coarseSystemTime',['../util_8c.html#a9ff416d9de6a1a68662c8628aed2e32e',1,'os_coarseSystemTime():&#160;util.c'],['../util_8h.html#a9ff416d9de6a1a68662c8628aed2e32e',1,'os_coarseSystemTime():&#160;util.c']]],
  ['os_5fprocesses_456',['os_processes',['../os__scheduler_8c.html#a583b140cea6b7a0bdc6ae1602b1459e2',1,'os_scheduler.c']]],
  ['os_5fprograms_457',['os_programs',['../os__scheduler_8c.html#ab1482a02c9d39e0fc773dcebb5cac2df',1,'os_scheduler.c']]]
];
