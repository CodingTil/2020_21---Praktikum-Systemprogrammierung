var searchData=
[
  ['select_5fmemory_428',['select_memory',['../os__mem__drivers_8c.html#a586e4c730a90597fa3b966b59204f8f3',1,'os_mem_drivers.c']]],
  ['set_5foperation_5fmode_429',['set_operation_mode',['../os__mem__drivers_8c.html#aeddc5b11419e6ee3b50408ea1cc3ee89',1,'os_mem_drivers.c']]],
  ['sethighnibble_430',['setHighNibble',['../os__memory_8c.html#a211f98b56ba22e7ec073c1b09b35d0ff',1,'os_memory.c']]],
  ['setlownibble_431',['setLowNibble',['../os__memory_8c.html#a79edcf2881c1b78d097495d05e7cec4f',1,'os_memory.c']]],
  ['setmapentry_432',['setMapEntry',['../os__memory_8c.html#aa0082364f445ac8cfacf8d0e873bcfb5',1,'os_memory.c']]],
  ['strategychanger_433',['strategyChanger',['../os__taskman_8c.html#a9f46441635483bb04c2857a3dbfdd925',1,'os_taskman.c']]],
  ['strategyselector_434',['strategySelector',['../os__taskman_8c.html#acf1b1da1d6a9f250f3a0b0e5d57b62ea',1,'os_taskman.c']]]
];
