var searchData=
[
  ['pagestate_476',['PageState',['../os__taskman_8c.html#a7c859f9337937dabe1129ee94c80f60b',1,'os_taskman.c']]],
  ['priority_477',['Priority',['../os__process_8h.html#a1bb679f7ad1508e942e35da9a0e7eabf',1,'os_process.h']]],
  ['process_478',['Process',['../os__process_8h.html#a3b5b0413545e0d4ff600b0a7203e3086',1,'os_process.h']]],
  ['processid_479',['ProcessID',['../os__process_8h.html#a9ae6ab2a896fd7ccf2c04cd38f9fa6c9',1,'os_process.h']]],
  ['processstate_480',['ProcessState',['../os__process_8h.html#a188e89ad1abd0d38668fb83d89aa8891',1,'os_process.h']]],
  ['program_481',['Program',['../os__process_8h.html#a1855c0ea815dd2a3323638f2fda0c38a',1,'os_process.h']]],
  ['programid_482',['ProgramID',['../os__process_8h.html#a1ab31056d5f9a7353e80e9718fe5698d',1,'os_process.h']]]
];
