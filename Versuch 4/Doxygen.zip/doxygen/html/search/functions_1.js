var searchData=
[
  ['delayms_323',['delayMs',['../util_8c.html#abbd75ad6fe1f975a544131cdf8d71287',1,'delayMs(uint16_t ms):&#160;util.c'],['../util_8h.html#abbd75ad6fe1f975a544131cdf8d71287',1,'delayMs(uint16_t ms):&#160;util.c']]],
  ['deselect_5fmemory_324',['deselect_memory',['../os__mem__drivers_8c.html#ad0810cb41540897c98168c15dbd8a929',1,'os_mem_drivers.c']]]
];
