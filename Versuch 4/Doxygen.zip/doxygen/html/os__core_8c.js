var os__core_8c =
[
    [ "os_errorPStr", "os__core_8c.html#a1ed51c8da9054e49d1f14175945cc563", null ],
    [ "os_init", "os__core_8c.html#a6cc2e63d83267ff5059bf0a76b302a09", null ],
    [ "os_init_timer", "os__core_8c.html#a6e2cb65995e0266255572244baf860f3", null ],
    [ "os_initScheduler", "os__core_8c.html#afcd3b8ded93499847533d52c2b08772a", null ]
];