var struct_page_state =
[
    [ "call", "struct_page_state.html#a628185dec95e935fc0f29a97e2d33421", null ],
    [ "param", "struct_page_state.html#af5db3df66a9031096e3aba02996aff42", null ],
    [ "range", "struct_page_state.html#aaf3b583e1c21913307084232f2f1f53c", null ]
];